package com.example.ttstest

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.TextToSpeech.OnInitListener
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale
import java.util.Random
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.MotionEvent
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat


class MainActivity2 : AppCompatActivity(), OnInitListener {

    private lateinit var tts: TextToSpeech
    private var selectedWord: String = ""
    private var recognizedWord: String = ""
    private var palabra: String = ""
    private var button:Button?=null
    private var button2:Button?=null
    private lateinit var resultTextView: TextView
    private lateinit var resultCongraView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        tts = TextToSpeech(this, this)

    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("es", "ES")) // Set Spanish locale

            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Handle language not supported error
            } else {
                randomizeFunctions()
                // TTS is ready to use
            }
        } else {
            // Handle initialization error
        }
    }

    // Don't forget to release the TTS engine in onDestroy()
    override fun onDestroy() {
        super.onDestroy()
        tts.shutdown()
    }




    private lateinit var speechRecognizer: SpeechRecognizer

    private fun setupSpeechRecognizer() {
        if(ContextCompat.checkSelfPermission
                (this,Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        )
        {
            checkPermissions()
        }
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        resultTextView = findViewById(R.id.recognizedText1)
        resultCongraView = findViewById(R.id.resultText)
        button = findViewById(R.id.startSpeechButton1)
        button2 = findViewById(R.id.startSpeechButton2)
        val speechRecognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault())
        // Set the recognition listener
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
            }

            override fun onBeginningOfSpeech() {
                resultTextView!!.setText("")
                resultTextView!!.setHint("Empieza a hablar")            }

            override fun onRmsChanged(rmsdB: Float) {
                // Called when the RMS value of the input audio changes
            }

            override fun onBufferReceived(buffer: ByteArray?) {
                // Called when partial recognition results are available
            }

            override fun onEndOfSpeech() {
                // Called when the user finishes speaking
            }

            override fun onError(error: Int) {
                // Called when an error occurs during the speech recognition
            }

            override fun onResults(results: Bundle?) {
                // Called when the final recognition results are available
                val recognizedWords = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!recognizedWords.isNullOrEmpty()) {
                    val recognizedWord = recognizedWords[0]
                    resultTextView.text = recognizedWord
                }
                checkAnswer(recognizedWord)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                // Called when partial recognition results are available
            }

            override fun onEvent(eventType: Int, params: Bundle?) {
                // Called when a speech recognition event occurs
            }

        })
        button!!.setOnTouchListener { view, motionEvent ->
            if(motionEvent.action == MotionEvent.ACTION_UP){
                speechRecognizer!!.stopListening()
            }
            if(motionEvent.action == MotionEvent.ACTION_DOWN){
                checkAnswer(selectedWord)
                speechRecognizer!!.startListening(
                    speechRecognizerIntent
                )
            }
            false
        }
    }

    private fun startSpeechRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)

        speechRecognizer.startListening(intent)
    }

    private fun stopSpeechRecognition() {
        speechRecognizer.stopListening()
    }

    private fun speechToTextFunction(callback: (recognizedWord: String) -> Unit) {
        setupSpeechRecognizer()
        val startSpeechButton: Button = findViewById(R.id.startSpeechButton1)
        startSpeechButton.setOnClickListener {
            // Start speech recognition
            val recognizedWord = startSpeechRecognition() // Replace with your logic to start and retrieve the recognized word

            // Call the callback function with the recognized word
            callback(recognizedWord.toString())
        }
    }
    private fun checkPermissions() {
        if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.M){
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.RECORD_AUDIO),
                RecordAudioRequestCode
            )
        }
    }


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if(requestCode == RecordAudioRequestCode
            && grantResults.isNotEmpty()){
            Toast.makeText(this,"Permission Granted", Toast.LENGTH_SHORT).show()
        }
    }
    companion object{
        const val RecordAudioRequestCode = 1
    }
    private fun randomizeFunctions(){
        val button2: Button = findViewById(R.id.startSpeechButton2)
        button2.setOnClickListener{
            val wordList = listOf("manzana", "banana", "casa", "mamá") // Example list of words
            val random = Random()
            var randomIndex = random.nextInt(wordList.size)
            var selectedWord = wordList[randomIndex]
            var palabra = selectedWord
            tts.speak(palabra, TextToSpeech.QUEUE_FLUSH, null, null)

        }
        checkAnswer(palabra)
    }
    private fun checkAnswer(value: String) {
        val button: Button = findViewById(R.id.startSpeechButton1)
        button.setOnClickListener {
            val texto = palabra
            // Text to be spoken

            speechToTextFunction { recognizedWord ->
                if (recognizedWord.trim().equals(texto.trim(), ignoreCase = true)) {
                    val text2 = "Felicitaciones"
                    resultCongraView.text = text2

                    // Text to be spoken
                    tts.speak(text2, TextToSpeech.QUEUE_FLUSH, null, null)
                    // Words match
                    // Perform your desired action here
                } else {
                    val text3 = "Inténtalo de nuevo"
                    resultCongraView.text = text3

                    tts.speak(text3, TextToSpeech.QUEUE_FLUSH, null, null)
                    // Words don't match
                    // Perform a different action or provide feedback
                }
            }
        }
    }

}

